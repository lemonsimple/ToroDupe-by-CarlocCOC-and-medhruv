# Toro Dupe

A boat dupe for 6b6t.org

### How to use:  
- Activate AutoMount
- Activate ToroDupe
- Enjoy

https://discord.io/Colonizadores
